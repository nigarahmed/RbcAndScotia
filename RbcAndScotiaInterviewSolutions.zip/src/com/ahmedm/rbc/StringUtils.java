package com.ahmedm.rbc;


public class StringUtils {
	/**
     * function to check whether a given string is MirrorSequence or not. The time complexity is close to n/2 where n is length of the string.
     * Assumptions:- (requirements are not properly stated, so assuming the following)
     * 1. The string is case-insensitive i.e. "KayAk" is a Mirror Sequence.
     * 2. If it contains only spaces, then it is not a Mirror sequence, i.e. "   " is not a mirror sequence.
     * 3. If it contains spaces at beginning/end/either side, then they will NOT be trimmed, they will be considered as part of the input String.
     * 4. if it contains only spaces, then it will NOT be considered as mirror sequence. 
     *
     * @param s
     * @return true if it is a mirror sequence otherwise false
     */
    public boolean isMirrorSequence(String s) {
    	// return false, if it is null or empty or contains only spaces
        if (s == null || s.isEmpty() || s.trim().isEmpty()) {
            return false;
        }

        int len = s.length() - 1;
        int i = 0;
        while (i <= len && Character.toLowerCase(s.charAt(i)) == Character.toLowerCase(s.charAt(len))) {
            i++;
            len--;
        }

        return i >= len;
    }
}
