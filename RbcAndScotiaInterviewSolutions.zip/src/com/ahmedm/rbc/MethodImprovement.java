package com.ahmedm.rbc;

public class MethodImprovement {

	/**
     * Given AMethod
     *
     * @param first
     * @param second
     * @param third
     * @return 1 or 2
     */
    public int AMethod(boolean first, boolean second, boolean third) {
        if (!first) {
            if (second) {
                if (third) {
                    return 1;
                } else if (!second) {
                    return 2;
                } else {
                    return 1;
                }
            } else {
                return 1;
            }
        } else if (!third) {
            if (!second) {
                return 2;
            }
        } else if (!second) {
            return 2;
        }
        if (!(third || !second)) {
            return 2;
        }
        return 1;
    }

    /**
     * Improved the AMethod
     *
     * @param first
     * @param second
     * @param third
     * @return 1 or 2
     */
    public int improvedAMethod(boolean first, boolean second, boolean third) {
        /**
         * return option 2 for (t, t, f), (t, f, t) and (t, f, f) else return 1 for all the other combinations
         */
        if (first && (!second || (second && !third))) {
            return 2;
        } else {
            return 1;
        }
    }

}
