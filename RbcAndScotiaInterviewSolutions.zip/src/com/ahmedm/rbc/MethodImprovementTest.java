package com.ahmedm.rbc;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class MethodImprovementTest {
	private static MethodImprovement mi;

	@Before
	public void setup() {
		mi = new MethodImprovement();
	}
	
	// case 1 - (true, true, true)
    @Test
	public void testTrueTrueTrue() {
		assertEquals(mi.AMethod(true, true, true), mi.improvedAMethod(true, true, true));
	}
	
    // case 2 - (true, true, false)
	@Test
	public void testTrueTrueFalse() {
		assertEquals(mi.AMethod(true, true, false), mi.improvedAMethod(true, true, false));
	}

    // case 3 - (true, false, true)
    @Test
	public void testTrueFalseTrue() {
    	assertEquals(mi.AMethod(true, false, true), mi.improvedAMethod(true, false, true));
    }

    // case 4 - (true, false, false)
    @Test
	public void testTrueFalseFalse() {
    	assertEquals(mi.AMethod(true, false, false), mi.improvedAMethod(true, false, false));
    }

    // case 5 - (false, true, true)
    @Test
	public void testFalseTrueTrue() {
    	assertEquals(mi.AMethod(false, true, true), mi.improvedAMethod(false, true, true));
    }

    // case 6 - (false, true, false)
    @Test
	public void testFalseTrueFalse() {
    	assertEquals(mi.AMethod(false, true, false), mi.improvedAMethod(false, true, false));
    }

    // case 7 - (false, false, true)
    @Test
	public void testFalseFalseTrue() {
    	assertEquals(mi.AMethod(false, false, true), mi.improvedAMethod(false, false, true));
    }

    // case 8 - (false, false, false)
    @Test
	public void testFalseFalseFalse() {
    	assertEquals(mi.AMethod(false, false, false), mi.improvedAMethod(false, false, false));
    }
}
