package com.ahmedm.rbc;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

public class StringUtilsTest {
	private StringUtils strUtil;
	
	@Before
	public void setup() {
		strUtil = new StringUtils();
	}

	@Test
	public void testValidValue() {
		assertTrue(strUtil.isMirrorSequence("kayak"));
	}
	
	@Test
	public void testValidValueWithImproperCase() {
		assertTrue(strUtil.isMirrorSequence("Able was I ere I saw Elba"));
	}
	
	@Test
	public void testValidValueWithSpacesAtBothSides() {
		assertTrue(strUtil.isMirrorSequence(" kayak "));
	}

	/**
	 * Failed Scenarios
	 */
	@Test
	public void testInvalidValue() {
		assertFalse(strUtil.isMirrorSequence("HelloH"));
	}
	
	@Test
	public void testOnlySpaces() {
		assertFalse(strUtil.isMirrorSequence("    "));
	}
	
	@Test
	public void testNullValue() {
		assertFalse(strUtil.isMirrorSequence(null));
	}
	
	@Test
	public void testEmptyValue() {
		assertFalse(strUtil.isMirrorSequence(""));
	}
	
	@Test
	public void testValidValueWithInitialSpaces() {
		assertFalse(strUtil.isMirrorSequence("   kayak"));
	}
	
	@Test
	public void testValidValueWithLeadingSpaces() {
		assertFalse(strUtil.isMirrorSequence("kayak    "));
	}
	
	@Test
	public void testValidValueWithIrregularSpacesAtBothSides() {
		assertFalse(strUtil.isMirrorSequence(" kayak    "));
	}
}
