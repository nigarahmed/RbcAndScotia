package com.ahmedm.scotia;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

class SudukoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public SudukoException(String msg) {
		super(msg);
	}
}

public class Suduko {
	private String filename;
	
	public Suduko() {
		filename = null;
	}
	
	public Suduko(String filename) {
		this.filename = filename;
	}
	

	public boolean verifySolution() throws SudukoException {
        Scanner s = null;
        String rows[] = new String[50];
        int totalRows = 0;
        Set<Character> rowSet = new HashSet<>();
        Set<Character> colSet = new HashSet<>();

        if(!Validator.validateFileName(filename)) {
        	throw new SudukoException("file:- " + filename + " is invalid");
        }
        
        try {
            s = new Scanner(new BufferedReader(new FileReader(filename)));
            while (s.hasNextLine()) {
                // read the data in String rows
                rows[totalRows++] = s.nextLine();
            }
        } catch (FileNotFoundException e) {
            throw new SudukoException("File: " + filename + " is not found");
        } finally {
            s.close();
        }
        
        if(Validator.isFileEmpty(totalRows)) {
        	throw new SudukoException("File: " + filename + " is empty");
        }
       
        /**
         * logic is, as there are 9x9:- 
         * 1. verify that each row contains unique number from 1 to 9
         * 2. verify that the corresponding column also contains unique number from 1 to 9. 
         * Example:- verify that row[1] contains unique numbers, then the corresponding column[1] also should contains unique digits.
         * use HashSet for pushing the data and verification as shown below
         */
        for(int i = 0; i < totalRows; i++) {
        	for(int j = 0; j < rows[0].length(); j++) {
                // validate that the number of rows should be equal to the number of digits
                if (!Validator.validateContentSize(rows[i], totalRows)) {
                    throw new SudukoException("rows = " + totalRows + ", rowDigits = " + rows[i].length() + " at " + i + "th row");
                }
                
        		/**
        		 * first condition is for scanning the rows, second condition is for scanning the columns.
        		 * 1. throw error if the row contains fewer digits
        		 * 2. throw error if the char is non-Numeric.
        		 * 3. throw error if the digit is already in its corresponding rowSet or colSet
        		 */
        		if(rows[i].length() != totalRows || !Character.isDigit(rows[i].charAt(j)) || rowSet.contains(rows[i].charAt(j)) || 
        				rows[j].length() != totalRows || !Character.isDigit(rows[j].charAt(i)) || colSet.contains(rows[j].charAt(i))) {
        			return false;
        		} else {
        			// add the digits into their corresponding HashSet
        			rowSet.add(rows[i].charAt(j));
        			colSet.add(rows[j].charAt(i));
        		}
        	}
        	
        	// reset both the sets as they will be used for the next rows and the next columns
        	rowSet.clear();
        	colSet.clear();
        }
        
		return true;
    }
	
	public String getFilename() {
		return filename;
	}


	public void setFilename(String filename) {
		this.filename = filename;
	}
	
	/**
	 * Validator class
	 *
	 */
	private static class Validator {
		public static boolean validateFileName(String filename) {
			if(filename == null || filename.isEmpty()) {
				return false;
			}
			return true;
		}
		
		public static boolean validateContentSize(String row, int totalRowCount) {
			if(row.isEmpty() || row.length() != totalRowCount) {
				return false;
			}
			
			return true;
		}
		
		public static boolean isFileEmpty(int rowCount) {
			return rowCount == 0;
		}
	}
}
